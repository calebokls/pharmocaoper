
  <footer class="footer-area section_gap">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-6 single-footer-widget">
              <h2 class="text-success">Express Import Allemand</h2>
              <p>Tous nos véhicules sont vendus avec contrôle technique ok, carte grise et non gage, carnet d’entretien et facture d’entretien. Aucun frais à prévoir et une garantie de 6 à 60 mois en fonction du véhicule</p>
            </div>
            <div class="col-lg-6 col-md-6 single-footer-widget">
              <h4>Contact</h4>
              <ul>
                <li><i class="fa fa-map-marker"></i> <a href="#">Hammer Deich 62, 20537 Hamburg</a></li>
                <li><i class="fa fa-phone"> </i><a href="#"> +33 780 70 95 14</a></li>
                <li><i class="fa fa-envelope"> </i><a href="#"> contact@meilleures-import-allemand.online</a></li>
                <li><i class="fa fa-clock-o"> </i> <a href="#">Lundi - Samedi 06:00AM - 11:00PM</a></li>
              </ul>
            </div>
          </div>
          <div class="footer-bottom row align-items-center">
            <p class="footer-text m-0 col-lg-8 col-md-12"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> Tout droit réservé | <a href="index.php">Express-Import-Allemand</a>
<!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --></p>
            <div class="col-lg-4 col-md-12 footer-social">
              <a href="#"><i class="fa fa-facebook"></i></a>
              <a href="#"><i class="fa fa-instagram"></i></a>
            </div>
          </div>
        </div>
      </footer>